-- ============================================================
--  RESET — Limpia todo y vuelve a crear desde cero
--  Ejecutar: psql -U postgres -d reservas_db -f reset_taller.sql
-- ============================================================

\c reservas_db

-- 1. Eliminar triggers
DROP TRIGGER IF EXISTS trg_validar_horas  ON reserva;
DROP TRIGGER IF EXISTS trg_estado_default ON reserva;

-- 2. Eliminar funciones
DROP FUNCTION IF EXISTS fn_validar_horas();
DROP FUNCTION IF EXISTS fn_estado_default();

-- 3. Eliminar índice
DROP INDEX IF EXISTS idx_reserva_fecha;

-- 4. Limpiar tablas (respeta FK)
TRUNCATE TABLE reserva RESTART IDENTITY CASCADE;
TRUNCATE TABLE espacio RESTART IDENTITY CASCADE;

-- 5. Revocar y eliminar usuarios/roles
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM rol_lector;
REVOKE ALL ON ALL TABLES IN SCHEMA public FROM rol_reservas;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM rol_reservas;
REVOKE USAGE ON SCHEMA public FROM rol_lector;
REVOKE USAGE ON SCHEMA public FROM rol_reservas;
REVOKE CONNECT ON DATABASE reservas_db FROM rol_lector;
REVOKE CONNECT ON DATABASE reservas_db FROM rol_reservas;

DROP USER IF EXISTS u_lector;
DROP USER IF EXISTS u_reservas;
DROP ROLE IF EXISTS rol_lector;
DROP ROLE IF EXISTS rol_reservas;

-- ============================================================
--  ACTIVIDAD 1 — Roles y usuarios
-- ============================================================

CREATE ROLE rol_lector;
CREATE ROLE rol_reservas;

GRANT CONNECT ON DATABASE reservas_db TO rol_lector;
GRANT CONNECT ON DATABASE reservas_db TO rol_reservas;

GRANT USAGE ON SCHEMA public TO rol_lector;
GRANT USAGE ON SCHEMA public TO rol_reservas;

GRANT SELECT ON ALL TABLES IN SCHEMA public TO rol_lector;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO rol_reservas;

GRANT INSERT ON TABLE reserva TO rol_reservas;
GRANT USAGE, SELECT ON SEQUENCE reserva_id_seq TO rol_reservas;

CREATE USER u_lector   WITH PASSWORD 'lector123';
CREATE USER u_reservas WITH PASSWORD 'reservas123';

GRANT rol_lector   TO u_lector;
GRANT rol_reservas TO u_reservas;

-- ============================================================
--  ACTIVIDAD 2 — Trigger: validar horas
-- ============================================================

CREATE OR REPLACE FUNCTION fn_validar_horas()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.hora_inicio >= NEW.hora_fin THEN
        RAISE EXCEPTION
            'Error: hora_inicio (%) debe ser menor que hora_fin (%).',
            NEW.hora_inicio, NEW.hora_fin;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_validar_horas
BEFORE INSERT ON reserva
FOR EACH ROW
EXECUTE FUNCTION fn_validar_horas();

-- ============================================================
--  ACTIVIDAD 3 — Trigger: estado por defecto
-- ============================================================

CREATE OR REPLACE FUNCTION fn_estado_default()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.estado IS NULL THEN
        NEW.estado := 'ACTIVA';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_estado_default
BEFORE INSERT ON reserva
FOR EACH ROW
EXECUTE FUNCTION fn_estado_default();

-- ============================================================
--  Datos base
-- ============================================================

INSERT INTO espacio (nombre, capacidad) VALUES
    ('Sala Miyu Suzuki',   10),
    ('Sala Momo Ayase',    20),
    ('Sala Chinatsu Kano', 15),
    ('Sala Hina Chono',    30),
    ('Auditorio Scarlet',  100);

-- ============================================================
--  ACTIVIDAD 4 — Índice por fecha
-- ============================================================

EXPLAIN SELECT * FROM reserva WHERE fecha = '2026-03-01';

CREATE INDEX idx_reserva_fecha ON reserva(fecha);

EXPLAIN SELECT * FROM reserva WHERE fecha = '2026-03-01';

-- ============================================================
--  EVIDENCIAS
-- ============================================================

-- Reserva correcta (estado NULL → ACTIVA automáticamente)
INSERT INTO reserva (espacio_id, fecha, hora_inicio, hora_fin, estado)
VALUES (1, '2026-03-01', '09:00', '10:00', NULL);

-- Reserva con estado explícito
INSERT INTO reserva (espacio_id, fecha, hora_inicio, hora_fin, estado)
VALUES (2, '2026-03-01', '14:00', '16:00', 'ACTIVA');

-- Reservas adicionales
INSERT INTO reserva (espacio_id, fecha, hora_inicio, hora_fin, estado)
VALUES (3, '2026-04-10', '08:00', '09:30', NULL);  -- Aira Shiratori

INSERT INTO reserva (espacio_id, fecha, hora_inicio, hora_fin, estado)
VALUES (4, '2026-04-10', '10:00', '12:00', NULL);  -- Kaoruko Waguri

INSERT INTO reserva (espacio_id, fecha, hora_inicio, hora_fin, estado)
VALUES (5, '2026-04-11', '11:00', '13:00', NULL);  -- Utage Kinoshita

INSERT INTO reserva (espacio_id, fecha, hora_inicio, hora_fin, estado)
VALUES (1, '2026-04-11', '15:00', '17:00', NULL);  -- Miwa Mikadono

INSERT INTO reserva (espacio_id, fecha, hora_inicio, hora_fin, estado)
VALUES (2, '2026-04-12', '09:00', '10:30', NULL);  -- Seiko Ayase

-- Reserva RECHAZADA (trigger en acción)
INSERT INTO reserva (espacio_id, fecha, hora_inicio, hora_fin, estado)
VALUES (1, '2026-03-01', '11:00', '09:00', NULL);

-- Resultado final
SELECT * FROM reserva;

-- Verificar roles existentes
\du

-- Verificar que u_lector SOLO puede leer
\c reservas_db u_lector
SELECT * FROM reserva;

-- Verificar que u_lector NO puede insertar (debe dar ERROR)
INSERT INTO reserva (espacio_id, fecha, hora_inicio, hora_fin)
VALUES (1, '2026-05-01', '08:00', '09:00');

-- Verificar que u_reservas SÍ puede insertar
\c reservas_db u_reservas
INSERT INTO reserva (espacio_id, fecha, hora_inicio, hora_fin)
VALUES (1, '2026-05-01', '08:00', '09:00');

-- Verificar que u_reservas NO puede eliminar (debe dar ERROR)
DELETE FROM reserva WHERE id = 1;

-- Volver a postgres y ver tabla final
\c reservas_db postgres
SELECT * FROM reserva;