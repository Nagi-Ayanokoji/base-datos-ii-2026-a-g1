ecommerce-relational-db: Este es el repositorio para la Base de datos relacional (>50 entidades)
. Aquí gestionaremos toda la estructura formal (DDL), los datos poblados y sintéticos (DML), así como los permisos y transacciones (DCL, TCL) para el núcleo del negocio: productos, pedidos, clientes e inventarios
.
ecommerce-analytics-nosql: Este corresponde al Repo (Aplicar Data Science)
. Está enfocado en el manejo de colecciones (MongoDB) para "datos sucios", logs de navegación y comportamiento de usuarios, sirviendo como base para los modelos de Data Science y analítica avanzada
.
ecommerce-service-api: Este es el repositorio para la Api (SOLID)
. Será el puente que conectará ambos mundos (SQL y NoSQL), implementando la lógica de negocio bajo principios de diseño robustos y encargándose de la "planificación para pasar datos limpios a SQL" como se describe en el segundo escenario
.

ERP para una Plataforma Global de E-commerce y Logística
Una tienda en línea simple tiene 10 entidades, pero un ERP que gestione toda la cadena de suministro supera las 50 sin dificultad.
Por qué encaja: La parte de Data Science puede usar los datos poblados para modelos de recomendación o predicción de demanda
.
Áreas para cubrir las >50 entidades:
Catálogo Maestro: Productos, variantes (color/talla), categorías, marcas, atributos dinámicos.
Inventario y Almacén: Pasillos, estantes, movimientos de stock, auditorías, múltiples bodegas.
Ventas y Clientes: Carrito, pedidos, estados de pago, devoluciones, cupones, programas de lealtad.
Logística de Envío: Transportistas, rutas, tracking, zonas geográficas, tarifas de peso/volumen.
Finanzas: Cuentas por cobrar, impuestos por región, conciliaciones bancarias, nómina básica de empleados.