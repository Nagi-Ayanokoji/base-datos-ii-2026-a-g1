
## 1. Configuración de Repositorios
Se han enlazado y configurado los tres repositorios principales en el espacio de trabajo local:
- `ecommerce-relational-db` (PostgreSQL - Núcleo del ERP)
- `ecommerce-analytics-nosql` (MongoDB - Data Science)
- `ecommerce-service-api` (API REST - SOLID)

## 2. Infraestructura (Docker)
- **Bases de Datos Contenerizadas:** Se han creado los archivos `.env`, `Dockerfile` y `docker-compose.yml` tanto para **PostgreSQL (v15)** como para **MongoDB (v6.0)**.
- **Validación:** Los contenedores inician correctamente y sus volúmenes persistentes funcionan.

## 3. Arquitectura Relacional (DDL)
Diseñamos un esquema robusto para soportar un ERP complejo (>50 entidades). Hemos creado **10 módulos SQL** (aprox. 38 tablas) con identificadores seguros (`UUID`) e idioma inglés:

1. **`00_init.sql`**: Configuración de extensión `uuid-ossp`.
2. **`01_users.sql`**: Autenticación y roles.
3. **`02_catalog.sql`**: Categorías, marcas y productos básicos.
4. **`03_variants.sql`**: Variantes de productos (ej. color, talla).
5. **`04_inventory.sql`**: Almacenes, pasillos, estantes y movimientos de stock.
6. **`05_customers.sql`**: Clientes, direcciones y programas de lealtad.
7. **`06_sales.sql`**: Carritos de compras, cupones y pedidos.
8. **`07_payments.sql`**: Métodos de pago, transacciones y devoluciones.
9. **`08_shipping.sql`**: Transportistas, rutas, zonas y tracking.
10. **`09_finance.sql`**: Impuestos, cuentas por cobrar y conciliaciones.
11. **`10_employees.sql`**: Departamentos, empleados y nómina.


